var prodData=JSON.parse(localStorage.getItem ("product")) || []



prodData.map(function(ele, index){
    let div=document.createElement("div");

    let brand=document.createElement("p")
    brand.innerText=ele.brand;

    let name=document.createElement("p")
    name.innerText=ele.name;

    let price=document.createElement("p")
    price.innerText=ele.price;

    let image=document.createElement("img")
    image.src=ele.image;

    let btn=document.createElement("button")
    btn.innerText="Remove";
    btn.addEventListener("click", function(){
        removedata(ele, index);
    })

    div.append(image,name, brand, price,btn)

    document.querySelector("#products_data").append(div)

})

function removedata(ele,index){
    prodData.splice(index,1)
    localStorage.setItem("product", JSON.stringify(prodData))
    window.location.reload();

}