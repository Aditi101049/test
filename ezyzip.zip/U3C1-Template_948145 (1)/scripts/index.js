//store the products array in localstorage as "data"
 
function Products(b,n,p,i){
    this.brand=b;
    this.name=n;
    this.price=p;
    this.image=i;
}
function storeData(e){
    e.preventDefault();
    let form=document.getElementById("product_form");
    let brand=form.product_brand.value;
    let name=form.product_name.value;
    let price=form.product_price.value;
    let image=form.product_image.value;

    let all=new Products(brand,name,price,image)
   // console.log(all)
   let data=JSON.parse(localStorage.getItem("product")) || []
   data.push(all)

   localStorage.setItem("product",JSON.stringify(data));
   console.log(all)
}
